// Nox Tab Footer v1: shared renderer for standalone and integrated packs.
uniform sampler2D Sampler0;
flat out int noxTabRectangle;
const vec3 noxTabPalette[16] = vec3[16](
 vec3(0,0,0),vec3(0,0,170),vec3(0,170,0),vec3(0,170,170),
 vec3(170,0,0),vec3(170,0,170),vec3(255,170,0),vec3(170,170,170),
 vec3(85,85,85),vec3(85,85,255),vec3(85,255,85),vec3(85,255,255),
 vec3(255,85,85),vec3(255,85,255),vec3(255,255,85),vec3(255,255,255));
void apply_nox_tab_footer() {
 noxTabRectangle = 0;
 if (ProjMat[2][3] != 0.0) return;
 ivec3 code = ivec3(round(Color.rgb * 255.0));
 bool characterCode = code.r >= 128;
 bool backgroundCode = code.r >= 16 && code.r <= 19;
 if (!characterCode && !backgroundCode) return;
 ivec2 size = textureSize(Sampler0,0), pixel = ivec2(floor(UV0 * vec2(size)));
 int corner = -1, kind = -1, widthByte = 0;
 for(int dy=-1;dy<=1;++dy) for(int dx=-1;dx<=1;++dx) {
  ivec2 samplePixel = clamp(pixel+ivec2(dx,dy),ivec2(0),size-ivec2(1));
  ivec4 tag = ivec4(round(texelFetch(Sampler0,samplePixel,0)*255.0));
  bool textTag = characterCode && tag.r == 253 && ((tag.b >= 32 && tag.b <= 33) || (tag.b >= 64 && tag.b <= 79));
  bool backgroundTag = backgroundCode && tag.b >= 200 && tag.b <= 235;
  if(tag.a == 1 && tag.g >= 11 && tag.g <= 14 && (textTag || backgroundTag)) {corner=tag.g-11;kind=tag.b;widthByte=tag.r;}
 }
 if(corner < 0) return; // Ordinary GUI/world text is untouched.
 bool right = corner >= 2, lower = corner == 1 || corner == 2;
 float guiWidth = ceil(2.0/ProjMat[0][0]-0.001), center=floor(guiWidth/2.0);
 vec2 point;
 if(kind >= 200) {
  int rows=code.b%32, columns=code.b/32+1;
  int meta=kind-200, requestedWidth=widthByte+(meta>=18?256:0);
  meta%=18;int lines=meta/3+1,segment=meta%3;
  float nativeColumn=float((code.r-16)*256+code.g);
  float columnWidth=min(nativeColumn,floor((guiWidth-50.0)/float(columns)));
  float gridWidth=columnWidth*float(columns)+5.0*float(columns-1);
  float tabWidth=max(gridWidth,min(float(requestedWidth)+4.0,guiWidth-50.0));
  float gridHalf=floor(gridWidth/2.0),tabHalf=floor(tabWidth/2.0),bottom=10.0+9.0*float(rows);
  if(segment==0) point=vec2(right?center+tabHalf+1.0:center-tabHalf-1.0,bottom+(lower?11.0+9.0*float(lines):0.0));
  else if(segment==1) point=vec2(right?center-gridHalf-1.0:center-tabHalf-1.0,lower?bottom:9.0);
  else point=vec2(right?center+tabHalf+1.0:center+gridHalf+1.0,lower?bottom:9.0);
  vertexColor=vec4(1.0);noxTabRectangle=1;
 } else {
  int packedCode=(code.r<<16)|(code.g<<8)|code.b;
  int palette=(packedCode>>18)&15, y=(packedCode>>10)&255, x=(packedCode&1023)-512;
  float w=kind>=64?float(kind-63):12.0,h=kind>=64?1.0:11.0;
  point=vec2(center+float(x)+(right?w:0.0),float(y)+(lower?h:0.0));
  if((packedCode&0x400000)!=0 && kind<64) point.x+=lower?-0.5:1.5;
  vertexColor=vec4(noxTabPalette[palette]/255.0,1.0);
  if(kind>=64) noxTabRectangle=2;
 }
 gl_Position.xy=(ProjMat*vec4(point,0.0,1.0)).xy;
}
