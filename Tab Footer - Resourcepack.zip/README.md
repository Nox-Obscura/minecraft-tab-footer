Nox Tab Footer v1.1 — Minecraft Java 26.2
使用 /trigger tab_footer 打开独立库编辑器；详见随包使用说明。
