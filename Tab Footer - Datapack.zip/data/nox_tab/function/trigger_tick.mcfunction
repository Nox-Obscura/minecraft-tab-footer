function nox_tab:probe/cleanup
execute if data storage nox_tab:config settings{restore_health_format:1b} as @a[tag=!NoxTabHealthRestored] run function nox_tab:health/restore_original
scoreboard players enable @a tab_footer
execute as @a[scores={tab_footer=1..}] at @s run function nox_tab:editor/open
execute if data storage nox_tab:input request run function nox_tab:input/dispatch with storage nox_tab:input request
