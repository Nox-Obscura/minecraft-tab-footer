data modify storage nox_tab:config settings.raw set value ""
data modify storage nox_tab:config settings.format set value "plain"
function nox_tab:disable
data remove storage nox_tab:work health
data remove storage nox_tab:work canvas
data remove storage nox_tab:work char
data remove storage nox_tab:work editor
data remove storage nox_tab:work frame
data remove storage nox_tab:work last_canvas
data remove storage nox_tab:work look
data remove storage nox_tab:work look2
data remove storage nox_tab:work look6
data remove storage nox_tab:work output
data remove storage nox_tab:work paint
data remove storage nox_tab:work previous_settings
data remove storage nox_tab:work queue
data remove storage nox_tab:work raw_root
data remove storage nox_tab:work section
data remove storage nox_tab:work source
data remove storage nox_tab:work state
data remove storage nox_tab:work style
data remove storage nox_tab:work submitted
data remove storage nox_tab:work template_vars
data remove storage nox_tab:work work
data remove storage nox_tab:input request
tellraw @s {text:"Tab 文案已清空。",color:"yellow"}
