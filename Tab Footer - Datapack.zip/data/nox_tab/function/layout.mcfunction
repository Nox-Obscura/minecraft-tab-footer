scoreboard players operation .Count NoxTabLayout = .Online NoxTabLayout
scoreboard players operation .ActiveCount NoxTabLayout = .Active NoxTabLayout
scoreboard players operation .NameWidthCache NoxTabLayout = .MaxNameWidth NoxTabLayout
scoreboard players operation .Rows NoxTabLayout = .Online NoxTabLayout
execute if score .Rows NoxTabLayout matches 81.. run scoreboard players set .Rows NoxTabLayout 80
execute if score .Rows NoxTabLayout matches ..0 run scoreboard players set .Rows NoxTabLayout 1
scoreboard players set .Columns NoxTabLayout 1
execute if score .Rows NoxTabLayout matches 21..40 run scoreboard players set .Columns NoxTabLayout 2
execute if score .Rows NoxTabLayout matches 41..60 run scoreboard players set .Columns NoxTabLayout 3
execute if score .Rows NoxTabLayout matches 61..80 run scoreboard players set .Columns NoxTabLayout 4
scoreboard players operation .Rows NoxTabLayout += .Columns NoxTabLayout
scoreboard players remove .Rows NoxTabLayout 1
scoreboard players operation .Rows NoxTabLayout /= .Columns NoxTabLayout
scoreboard players set .Code NoxTabLayout 32
scoreboard players operation .Code NoxTabLayout *= .Columns NoxTabLayout
scoreboard players remove .Code NoxTabLayout 32
scoreboard players operation .Code NoxTabLayout += .Rows NoxTabLayout
scoreboard players operation .NativeColumn NoxTabLayout = .MaxNameWidth NoxTabLayout
scoreboard players add .NativeColumn NoxTabLayout 28
scoreboard players operation .NativeColumn NoxTabLayout += .MaxScoreWidth NoxTabLayout
scoreboard players operation .ScoreWidthCache NoxTabLayout = .MaxScoreWidth NoxTabLayout
execute if score .NativeColumn NoxTabLayout matches 1024.. run scoreboard players set .NativeColumn NoxTabLayout 1023
execute store result storage nox_tab:work paint.width int 1 run scoreboard players get .NativeColumn NoxTabLayout
execute store result storage nox_tab:work paint.code int 1 run scoreboard players get .Code NoxTabLayout
execute store result score .MaxTextWidth NoxTabLayout run data get storage nox_tab:work canvas.max_width 1
execute store result score .Lines NoxTabLayout run data get storage nox_tab:work canvas.lines_count 1
scoreboard players set .BgIndex NoxTabLayout 6
scoreboard players operation .BgIndex NoxTabLayout *= .MaxTextWidth NoxTabLayout
scoreboard players set .Three NoxTabLayout 3
scoreboard players operation .Temp NoxTabLayout = .Lines NoxTabLayout
scoreboard players remove .Temp NoxTabLayout 1
scoreboard players operation .BgIndex NoxTabLayout += .Temp NoxTabLayout
execute store result storage nox_tab:work paint.bg_index int 1 run scoreboard players get .BgIndex NoxTabLayout
function nox_tab:paint/start with storage nox_tab:work paint
scoreboard players display numberformat @a NoxTabList
tag @a remove NoxTabCarrier
tag @a[gamemode=!spectator,limit=1] add NoxTabCarrier
scoreboard players add .Revision NoxTabLayout 1

function nox_tab:paint/apply with storage nox_tab:work
scoreboard objectives setdisplay list NoxTabList
schedule function nox_tab:tick 5t replace
