data modify storage nox_tab:work submitted set from storage nox_tab:input request
data modify storage nox_tab:work previous_settings set from storage nox_tab:config settings
data modify storage nox_tab:config settings.raw set from storage nox_tab:work submitted.raw
data modify storage nox_tab:config settings.target set from storage nox_tab:work submitted.target
data modify storage nox_tab:config settings.format set from storage nox_tab:work submitted.format
execute if data storage nox_tab:config settings{target:"@s"} run function nox_tab:save_self with entity @s
execute if data storage nox_tab:config settings{raw:""} run return run function nox_tab:reset
scoreboard players set .ResolveOK NoxTabLayout 0
execute store result score .ResolveOK NoxTabLayout run function nox_tab:resolve with storage nox_tab:config settings
execute if score .ResolveOK NoxTabLayout matches 0 run return run function nox_tab:save_failed
function nox_tab:enable
tellraw @s {text:"Tab 文案已保存。",color:"green"}
execute if score .Truncated NoxTabLayout matches 1 run tellraw @s {text:"内容超过六行，显示前六行。",color:"yellow"}
