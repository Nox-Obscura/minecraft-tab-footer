data modify storage nox_tab:config settings.enabled set value 0b
scoreboard players display numberformat @a NoxTabList
tag @a remove NoxTabCarrier
scoreboard objectives setdisplay list
execute unless data storage nox_tab:config settings{restore:""} run function nox_tab:restore with storage nox_tab:config settings
