$scoreboard objectives setdisplay list $(restore)
