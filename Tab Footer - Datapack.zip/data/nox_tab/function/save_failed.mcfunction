data modify storage nox_tab:config settings set from storage nox_tab:work previous_settings
function nox_tab:refresh
tellraw @s {text:"未保存：请检查目标选择器和文本组件格式。",color:"red"}
