data modify storage nox_tab:work work.frame set from storage nox_tab:work work.queue[0]
data remove storage nox_tab:work work.queue[0]
execute if data storage nox_tab:work work.frame.component.bold run data modify storage nox_tab:work work.frame.bold set from storage nox_tab:work work.frame.component.bold
execute if data storage nox_tab:work work.frame.component.font run data modify storage nox_tab:work work.frame.font set from storage nox_tab:work work.frame.component.font
data modify storage nox_tab:work work.text set value ""
execute if data storage nox_tab:work work.frame.component.text run data modify storage nox_tab:work work.text set from storage nox_tab:work work.frame.component.text
execute unless data storage nox_tab:work work.frame.component.text unless data storage nox_tab:work work.frame.component.extra unless data storage nox_tab:work work.frame.component.translate run data modify storage nox_tab:work work.text set from storage nox_tab:work work.frame.component
execute if data storage nox_tab:work work.frame.component.translate run function nox_tab:name/measure_translation with storage nox_tab:work work.frame.component
execute store result score .TextLength NoxTabLayout run data get storage nox_tab:work work.text
scoreboard players set .LegacyBold NoxTabLayout 0
execute if data storage nox_tab:work work.frame{bold:1b} run scoreboard players set .LegacyBold NoxTabLayout 1
execute if score .TextLength NoxTabLayout matches 1.. run function nox_tab:name/measure_chars
execute if data storage nox_tab:work work.frame.component.extra[0] run function nox_tab:name/measure_children
execute if data storage nox_tab:work work.queue[0] run function nox_tab:name/measure_component
