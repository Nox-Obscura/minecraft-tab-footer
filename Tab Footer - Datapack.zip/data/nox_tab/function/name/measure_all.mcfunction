scoreboard players set .MaxNameWidth NoxTabLayout 0
kill @e[tag=NoxTabNameProbe]
execute summon minecraft:item_display run function nox_tab:name/probe
