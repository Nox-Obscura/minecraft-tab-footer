data merge entity @s {Tags:["NoxTabNameProbe"],view_range:0f,Invulnerable:1b,NoGravity:1b,Silent:1b}
execute as @a run function nox_tab:name/measure_player
kill @s
