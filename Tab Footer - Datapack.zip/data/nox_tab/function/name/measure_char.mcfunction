execute if data storage nox_tab:work work{char:'"'} run return 0
execute if data storage nox_tab:work work{char:'\\'} run return 0
$execute if data storage nox_tab:meta name_widths."$(font)"."$(char)" store result score .GlyphWidth NoxTabLayout run data get storage nox_tab:meta name_widths."$(font)"."$(char)" 1
