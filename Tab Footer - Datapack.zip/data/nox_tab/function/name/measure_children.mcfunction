data modify storage nox_tab:work work.queue append from storage nox_tab:work work.frame
data modify storage nox_tab:work work.queue[-1].component set from storage nox_tab:work work.frame.component.extra[0]
data remove storage nox_tab:work work.frame.component.extra[0]
execute if data storage nox_tab:work work.frame.component.extra[0] run function nox_tab:name/measure_children
