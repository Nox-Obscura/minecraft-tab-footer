$data modify storage nox_tab:work work.text set value "$(translate)"
$data modify storage nox_tab:work work.text set from storage nox_tab:meta translations."$(translate)"
execute if data storage nox_tab:work work.frame.component.fallback run data modify storage nox_tab:work work.text set from storage nox_tab:work work.frame.component.fallback
