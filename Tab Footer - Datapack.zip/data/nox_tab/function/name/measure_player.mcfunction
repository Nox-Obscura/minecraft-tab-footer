loot replace entity @e[type=item_display,tag=NoxTabNameProbe,distance=..1,limit=1] container.0 loot nox_tab:name
data modify storage nox_tab:work work.queue set value [{component:"",bold:0b,font:"minecraft:default"}]
data modify storage nox_tab:work work.queue[0].component set from entity @e[type=item_display,tag=NoxTabNameProbe,distance=..1,limit=1] item.components."minecraft:custom_name"
scoreboard players set .NameWidth NoxTabLayout 0
function nox_tab:name/measure_component
execute if score .NameWidth NoxTabLayout > .MaxNameWidth NoxTabLayout run scoreboard players operation .MaxNameWidth NoxTabLayout = .NameWidth NoxTabLayout
