data modify storage nox_tab:work work.section set string storage nox_tab:work work.text 0 1
data modify storage nox_tab:work work.text set string storage nox_tab:work work.text 1
execute if data storage nox_tab:work work{section:"0"} run scoreboard players set .LegacyBold NoxTabLayout 0
execute if data storage nox_tab:work work{section:"1"} run scoreboard players set .LegacyBold NoxTabLayout 0
execute if data storage nox_tab:work work{section:"2"} run scoreboard players set .LegacyBold NoxTabLayout 0
execute if data storage nox_tab:work work{section:"3"} run scoreboard players set .LegacyBold NoxTabLayout 0
execute if data storage nox_tab:work work{section:"4"} run scoreboard players set .LegacyBold NoxTabLayout 0
execute if data storage nox_tab:work work{section:"5"} run scoreboard players set .LegacyBold NoxTabLayout 0
execute if data storage nox_tab:work work{section:"6"} run scoreboard players set .LegacyBold NoxTabLayout 0
execute if data storage nox_tab:work work{section:"7"} run scoreboard players set .LegacyBold NoxTabLayout 0
execute if data storage nox_tab:work work{section:"8"} run scoreboard players set .LegacyBold NoxTabLayout 0
execute if data storage nox_tab:work work{section:"9"} run scoreboard players set .LegacyBold NoxTabLayout 0
execute if data storage nox_tab:work work{section:"a"} run scoreboard players set .LegacyBold NoxTabLayout 0
execute if data storage nox_tab:work work{section:"A"} run scoreboard players set .LegacyBold NoxTabLayout 0
execute if data storage nox_tab:work work{section:"b"} run scoreboard players set .LegacyBold NoxTabLayout 0
execute if data storage nox_tab:work work{section:"B"} run scoreboard players set .LegacyBold NoxTabLayout 0
execute if data storage nox_tab:work work{section:"c"} run scoreboard players set .LegacyBold NoxTabLayout 0
execute if data storage nox_tab:work work{section:"C"} run scoreboard players set .LegacyBold NoxTabLayout 0
execute if data storage nox_tab:work work{section:"d"} run scoreboard players set .LegacyBold NoxTabLayout 0
execute if data storage nox_tab:work work{section:"D"} run scoreboard players set .LegacyBold NoxTabLayout 0
execute if data storage nox_tab:work work{section:"e"} run scoreboard players set .LegacyBold NoxTabLayout 0
execute if data storage nox_tab:work work{section:"E"} run scoreboard players set .LegacyBold NoxTabLayout 0
execute if data storage nox_tab:work work{section:"f"} run scoreboard players set .LegacyBold NoxTabLayout 0
execute if data storage nox_tab:work work{section:"F"} run scoreboard players set .LegacyBold NoxTabLayout 0
execute if data storage nox_tab:work work{section:"r"} run scoreboard players set .LegacyBold NoxTabLayout 0
execute if data storage nox_tab:work work{section:"R"} run scoreboard players set .LegacyBold NoxTabLayout 0
execute if data storage nox_tab:work work{section:"l"} run scoreboard players set .LegacyBold NoxTabLayout 1
execute if data storage nox_tab:work work{section:"L"} run scoreboard players set .LegacyBold NoxTabLayout 1
execute store result score .TextLength NoxTabLayout run data get storage nox_tab:work work.text
execute if score .TextLength NoxTabLayout matches 1.. run function nox_tab:name/measure_chars
