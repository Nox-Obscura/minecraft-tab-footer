data modify storage nox_tab:work work.char set string storage nox_tab:work work.text 0 1
data modify storage nox_tab:work work.text set string storage nox_tab:work work.text 1
execute if data storage nox_tab:work work{char:"§"} run return run function nox_tab:name/measure_section
scoreboard players set .GlyphWidth NoxTabLayout 6
data modify storage nox_tab:work work.font set from storage nox_tab:work work.frame.font
execute if data storage nox_tab:work work{char:'"'} run scoreboard players set .GlyphWidth NoxTabLayout 4
execute unless data storage nox_tab:work work{char:'"'} unless data storage nox_tab:work work{char:'\\'} run function nox_tab:name/measure_char with storage nox_tab:work work
execute if score .LegacyBold NoxTabLayout matches 1 run scoreboard players add .GlyphWidth NoxTabLayout 1
scoreboard players operation .NameWidth NoxTabLayout += .GlyphWidth NoxTabLayout
execute store result score .TextLength NoxTabLayout run data get storage nox_tab:work work.text
execute if score .TextLength NoxTabLayout matches 1.. run function nox_tab:name/measure_chars
