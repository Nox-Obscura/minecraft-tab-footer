execute unless data storage nox_tab:config initialized run data modify storage nox_tab:config settings set value {"raw":"§e© NOX-OBSCURA 2026\n§a更多小游戏及优惠! §b§lSTORE.BESTNOX.TOP","format":"plain","target":"@a[limit=1]","restore":"health","enabled":true}
data modify storage nox_tab:config initialized set value 1b
execute unless data storage nox_tab:config settings.score_objective run data modify storage nox_tab:config settings.score_objective set value "health"
data modify storage nox_tab:config settings.restore_health_format set value 1b
function nox_tab:load
