data modify storage nox_tab:config settings.enabled set value 1b
scoreboard players set .Count NoxTabLayout -1
function nox_tab:tick
