scoreboard players set .Resolved NoxTabLayout 0
$execute as $(target) at @s unless score .Resolved NoxTabLayout matches 1 run function nox_tab:resolve_target
execute unless score .Resolved NoxTabLayout matches 1 run return 0
return 1
