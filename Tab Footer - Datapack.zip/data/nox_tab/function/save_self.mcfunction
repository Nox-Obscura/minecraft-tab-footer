$data modify storage nox_tab:config settings.target set value "@a[nbt={UUID:$(UUID)},limit=1]"
