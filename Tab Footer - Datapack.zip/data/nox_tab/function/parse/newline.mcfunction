function nox_tab:parse/finish_line
execute if score .Lines NoxTabLayout matches 6.. run return run function nox_tab:parse/truncated
scoreboard players add .Lines NoxTabLayout 1
scoreboard players set .LineWidth NoxTabLayout 0
data modify storage nox_tab:work canvas.lines append value {chars:[],width:0}
