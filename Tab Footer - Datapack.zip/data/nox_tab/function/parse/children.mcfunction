data modify storage nox_tab:work queue insert 0 from storage nox_tab:work frame
data modify storage nox_tab:work queue[0].component set from storage nox_tab:work frame.component.extra[-1]
data remove storage nox_tab:work frame.component.extra[-1]
execute if data storage nox_tab:work frame.component.extra[-1] run function nox_tab:parse/children
