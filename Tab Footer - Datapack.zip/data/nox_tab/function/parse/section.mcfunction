execute store result score .SourceLength NoxTabLayout run data get storage nox_tab:work source
execute if score .SourceLength NoxTabLayout matches 0 run return 0
data modify storage nox_tab:work section set string storage nox_tab:work source 0 1
data modify storage nox_tab:work source set string storage nox_tab:work source 1
function nox_tab:parse/section_code with storage nox_tab:work
