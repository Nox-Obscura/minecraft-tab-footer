$execute if data storage nox_tab:meta colors."$(color)" run data modify storage nox_tab:work frame.style.palette set from storage nox_tab:meta colors."$(color)"
