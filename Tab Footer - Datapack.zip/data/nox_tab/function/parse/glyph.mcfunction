scoreboard players set .Advance NoxTabLayout 6
execute if data storage nox_tab:work {char:'"'} run scoreboard players set .Advance NoxTabLayout 4
execute unless data storage nox_tab:work {char:'"'} unless data storage nox_tab:work {char:'\\'} run function nox_tab:parse/glyph_width with storage nox_tab:work
execute if data storage nox_tab:work style{bold:1b} run scoreboard players add .Advance NoxTabLayout 1
scoreboard players operation .NextWidth NoxTabLayout = .LineWidth NoxTabLayout
scoreboard players operation .NextWidth NoxTabLayout += .Advance NoxTabLayout
execute if score .NextWidth NoxTabLayout matches 257.. run function nox_tab:parse/newline
execute if score .Stop NoxTabLayout matches 1 run return 0
data modify storage nox_tab:work canvas.lines[-1].chars append from storage nox_tab:work style
data modify storage nox_tab:work canvas.lines[-1].chars[-1].char set from storage nox_tab:work char
execute store result storage nox_tab:work canvas.lines[-1].chars[-1].advance int 1 run scoreboard players get .Advance NoxTabLayout
scoreboard players operation .LineWidth NoxTabLayout += .Advance NoxTabLayout
