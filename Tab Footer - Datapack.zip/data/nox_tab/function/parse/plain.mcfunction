execute if score .Stop NoxTabLayout matches 1 run return 0
execute store result score .SourceLength NoxTabLayout run data get storage nox_tab:work source
execute if score .SourceLength NoxTabLayout matches 0 run return 0
data modify storage nox_tab:work look2 set value ""
data modify storage nox_tab:work look6 set value ""
execute if score .SourceLength NoxTabLayout matches 2.. run data modify storage nox_tab:work look2 set string storage nox_tab:work source 0 2
execute if score .SourceLength NoxTabLayout matches 6.. run data modify storage nox_tab:work look6 set string storage nox_tab:work source 0 6
execute if data storage nox_tab:work {"look6":"\\u00a7"} run function nox_tab:parse/escape_section
execute if data storage nox_tab:work {"look6":"\\u00a7"} run return run function nox_tab:parse/plain
execute if data storage nox_tab:work {"look6":"|u00a7"} run function nox_tab:parse/escape_section
execute if data storage nox_tab:work {"look6":"|u00a7"} run return run function nox_tab:parse/plain
execute if data storage nox_tab:work {"look2":"\\n"} run function nox_tab:parse/escape_newline
execute if data storage nox_tab:work {"look2":"\\n"} run return run function nox_tab:parse/plain
execute if data storage nox_tab:work {"look2":"\\r"} run function nox_tab:parse/escape_cr
execute if data storage nox_tab:work {"look2":"\\r"} run return run function nox_tab:parse/plain
data modify storage nox_tab:work char set string storage nox_tab:work source 0 1
data modify storage nox_tab:work source set string storage nox_tab:work source 1
execute if data storage nox_tab:work {"char":"§"} run function nox_tab:parse/section
execute if data storage nox_tab:work {"char":"§"} run return run function nox_tab:parse/plain
execute if data storage nox_tab:work {"char":"\n"} run function nox_tab:parse/newline
execute if data storage nox_tab:work {"char":"\n"} run return run function nox_tab:parse/plain
execute if data storage nox_tab:work {"char":"\r"} run return run function nox_tab:parse/plain
function nox_tab:parse/glyph
function nox_tab:parse/plain
