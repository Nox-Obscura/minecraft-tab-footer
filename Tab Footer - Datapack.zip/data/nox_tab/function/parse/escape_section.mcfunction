data modify storage nox_tab:work source set string storage nox_tab:work source 6
function nox_tab:parse/section
