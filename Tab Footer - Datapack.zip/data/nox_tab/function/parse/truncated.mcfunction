scoreboard players set .Stop NoxTabLayout 1
scoreboard players set .Truncated NoxTabLayout 1
