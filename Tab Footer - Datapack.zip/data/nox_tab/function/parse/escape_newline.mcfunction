data modify storage nox_tab:work source set string storage nox_tab:work source 2
function nox_tab:parse/newline
