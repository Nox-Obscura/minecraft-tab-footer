execute if score .Stop NoxTabLayout matches 1 run return 0
data modify storage nox_tab:work frame set from storage nox_tab:work queue[0]
data remove storage nox_tab:work queue[0]
execute if data storage nox_tab:work frame.component.color run function nox_tab:parse/component_color with storage nox_tab:work frame.component
execute if data storage nox_tab:work frame.component.bold run data modify storage nox_tab:work frame.style.bold set from storage nox_tab:work frame.component.bold
execute if data storage nox_tab:work frame.component.italic run data modify storage nox_tab:work frame.style.italic set from storage nox_tab:work frame.component.italic
execute if data storage nox_tab:work frame.component.underlined run data modify storage nox_tab:work frame.style.underlined set from storage nox_tab:work frame.component.underlined
execute if data storage nox_tab:work frame.component.strikethrough run data modify storage nox_tab:work frame.style.strikethrough set from storage nox_tab:work frame.component.strikethrough
data modify storage nox_tab:work style set from storage nox_tab:work frame.style
data modify storage nox_tab:work source set value ""
execute if data storage nox_tab:work frame.component.text run data modify storage nox_tab:work source set from storage nox_tab:work frame.component.text
execute unless data storage nox_tab:work frame.component.text unless data storage nox_tab:work frame.component.extra unless data storage nox_tab:work frame.component.translate run data modify storage nox_tab:work source set from storage nox_tab:work frame.component
execute if data storage nox_tab:work frame.component.translate run data modify storage nox_tab:work source set from storage nox_tab:work frame.component.translate
execute if data storage nox_tab:work frame.component.fallback run data modify storage nox_tab:work source set from storage nox_tab:work frame.component.fallback
function nox_tab:parse/plain
execute if data storage nox_tab:work frame.component.extra[0] run function nox_tab:parse/children
execute if data storage nox_tab:work queue[0] run function nox_tab:parse/component
