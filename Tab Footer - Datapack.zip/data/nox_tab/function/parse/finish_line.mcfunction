execute store result storage nox_tab:work canvas.lines[-1].width int 1 run scoreboard players get .LineWidth NoxTabLayout
execute store result score .MaxTextWidth NoxTabLayout run data get storage nox_tab:work canvas.max_width 1
execute if score .LineWidth NoxTabLayout > .MaxTextWidth NoxTabLayout store result storage nox_tab:work canvas.max_width int 1 run scoreboard players get .LineWidth NoxTabLayout
