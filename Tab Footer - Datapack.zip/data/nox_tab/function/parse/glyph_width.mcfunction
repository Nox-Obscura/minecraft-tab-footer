$execute if data storage nox_tab:meta glyph_widths."$(char)" store result score .Advance NoxTabLayout run data get storage nox_tab:meta glyph_widths."$(char)" 1
$execute unless data storage nox_tab:meta glyph_widths."$(char)" run data modify storage nox_tab:work char set value "?"
