kill @e[tag=NoxTabNameProbe]
kill @e[tag=NoxTabComponentProbe]
