data merge entity @s {Tags:["NoxTabComponentProbe"],view_range:0f,Invulnerable:1b,NoGravity:1b,Silent:1b}
