data modify storage nox_tab:work canvas set value {lines:[{chars:[],width:0}],max_width:0}
scoreboard players set .Lines NoxTabLayout 1
scoreboard players set .LineWidth NoxTabLayout 0
scoreboard players set .Stop NoxTabLayout 0
scoreboard players set .Truncated NoxTabLayout 0
data modify storage nox_tab:work style set value {palette:15,bold:0b,italic:0b,underlined:0b,strikethrough:0b}
execute if data storage nox_tab:config settings{format:"plain"} run data modify storage nox_tab:work source set from storage nox_tab:config settings.raw
execute if data storage nox_tab:config settings{format:"plain"} run function nox_tab:parse/plain
scoreboard players set .ComponentOK NoxTabLayout 0
execute if data storage nox_tab:config settings{format:"component"} run function nox_tab:resolve_component with storage nox_tab:config settings
execute if data storage nox_tab:config settings{format:"component"} if score .ComponentOK NoxTabLayout matches 0 run return 0
execute if score .Stop NoxTabLayout matches 0 run function nox_tab:parse/finish_line
execute store result storage nox_tab:work canvas.lines_count int 1 run scoreboard players get .Lines NoxTabLayout
scoreboard players set .Resolved NoxTabLayout 1
return 1
