scoreboard players set .Poll NoxTabLayout 0
execute unless entity @a run return run function nox_tab:idle
scoreboard players set .ResolveOK NoxTabLayout 0
execute store result score .ResolveOK NoxTabLayout run function nox_tab:resolve with storage nox_tab:config settings
execute if score .ResolveOK NoxTabLayout matches 0 run return run function nox_tab:idle
function nox_tab:health/sync
execute as @a[limit=1] at @s run function nox_tab:name/measure_all
execute store success score .CanvasChanged NoxTabLayout run data modify storage nox_tab:work last_canvas set from storage nox_tab:work canvas
execute unless score .Online NoxTabLayout = .Count NoxTabLayout run return run function nox_tab:layout
execute unless score .Active NoxTabLayout = .ActiveCount NoxTabLayout run return run function nox_tab:layout
execute if entity @a[gamemode=!spectator] unless entity @a[tag=NoxTabCarrier,gamemode=!spectator] run return run function nox_tab:layout
execute unless score .MaxScoreWidth NoxTabLayout = .ScoreWidthCache NoxTabLayout run return run function nox_tab:layout
execute unless score .MaxNameWidth NoxTabLayout = .NameWidthCache NoxTabLayout run return run function nox_tab:layout
execute if score .CanvasChanged NoxTabLayout matches 1 run return run function nox_tab:layout
schedule function nox_tab:tick 5t replace
