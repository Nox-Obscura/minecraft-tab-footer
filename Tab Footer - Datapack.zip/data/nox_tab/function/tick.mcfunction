execute store result score .Online NoxTabLayout run execute if entity @a
execute store result score .Active NoxTabLayout run execute if entity @a[gamemode=!spectator]
execute unless data storage nox_tab:config settings{enabled:1b} run return run function nox_tab:idle
function nox_tab:health/sync
execute unless score .MaxScoreWidth NoxTabLayout = .ScoreWidthCache NoxTabLayout run return run function nox_tab:refresh
execute unless score .Online NoxTabLayout = .Count NoxTabLayout run return run function nox_tab:refresh
execute unless score .Active NoxTabLayout = .ActiveCount NoxTabLayout run return run function nox_tab:refresh
execute if entity @a[gamemode=!spectator] unless entity @a[tag=NoxTabCarrier,gamemode=!spectator] run return run function nox_tab:refresh
scoreboard players add .Poll NoxTabLayout 1
execute if score .Poll NoxTabLayout matches 4.. run function nox_tab:refresh
schedule function nox_tab:tick 5t replace
