$data modify storage nox_tab:work paint.width_color set from storage nox_tab:meta width_colors[$(width)]
$data modify storage nox_tab:work paint.code_color set from storage nox_tab:meta codes[$(code)]
$data modify storage nox_tab:work paint.background set from storage nox_tab:meta backgrounds[$(bg_index)]
data modify storage nox_tab:work output set value [{text:"",font:"nox_tab:background",bold:false,italic:false,shadow_color:0,extra:[{text:"\uefff"}]}]
data modify storage nox_tab:work output[0].text set from storage nox_tab:work paint.background
function nox_tab:paint/background_color with storage nox_tab:work paint
data modify storage nox_tab:work paint.lines set from storage nox_tab:work canvas.lines
scoreboard players set .LineIndex NoxTabLayout 0
function nox_tab:paint/line
data modify storage nox_tab:work output append value {text:"\ueffe",font:"nox_tab:background",shadow_color:0}
