$data modify storage nox_tab:work output[0].color set value "#$(width_color)$(code_color)"
