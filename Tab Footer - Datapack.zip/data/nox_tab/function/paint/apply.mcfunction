scoreboard players set @a NoxTabCache -2147483648
function nox_tab:health/sync
