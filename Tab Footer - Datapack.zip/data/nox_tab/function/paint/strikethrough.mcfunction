scoreboard players add .X NoxTabLayout 1
scoreboard players add .Y NoxTabLayout 5
function nox_tab:paint/decoration
scoreboard players remove .X NoxTabLayout 1
scoreboard players remove .Y NoxTabLayout 5
