execute store result score .PaintWidth NoxTabLayout run data get storage nox_tab:work paint.lines[0].width 1
scoreboard players set .Two NoxTabLayout 2
scoreboard players operation .PaintWidth NoxTabLayout /= .Two NoxTabLayout
scoreboard players set .Cursor NoxTabLayout 0
execute if data storage nox_tab:work paint.lines[0].chars[0] run function nox_tab:paint/character
data remove storage nox_tab:work paint.lines[0]
scoreboard players add .LineIndex NoxTabLayout 1
execute if data storage nox_tab:work paint.lines[0] run function nox_tab:paint/line
