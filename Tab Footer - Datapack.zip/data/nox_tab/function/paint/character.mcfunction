data modify storage nox_tab:work paint.character set from storage nox_tab:work paint.lines[0].chars[0]
scoreboard players set .X NoxTabLayout 511
scoreboard players operation .X NoxTabLayout += .Cursor NoxTabLayout
scoreboard players operation .X NoxTabLayout -= .PaintWidth NoxTabLayout
scoreboard players set .Y NoxTabLayout 9
scoreboard players operation .Y NoxTabLayout *= .Rows NoxTabLayout
scoreboard players set .Temp NoxTabLayout 9
scoreboard players operation .Temp NoxTabLayout *= .LineIndex NoxTabLayout
scoreboard players operation .Y NoxTabLayout += .Temp NoxTabLayout
scoreboard players add .Y NoxTabLayout 18
function nox_tab:paint/color
# Every custom glyph is followed by an equal negative advance; only the final 2px spacer sizes the score column.
data modify storage nox_tab:work output append value {text:"",font:"nox_tab:normal",bold:false,italic:false,shadow_color:0,extra:[{text:"\uefff"}]}
data modify storage nox_tab:work output[-1].text set from storage nox_tab:work paint.character.char
execute if data storage nox_tab:work paint.character{bold:1b} run data modify storage nox_tab:work output[-1].font set value "nox_tab:bold"
function nox_tab:paint/character_color with storage nox_tab:work paint
execute if data storage nox_tab:work paint.character{underlined:1b} run function nox_tab:paint/underline
execute if data storage nox_tab:work paint.character{strikethrough:1b} run function nox_tab:paint/strikethrough
execute store result score .Advance NoxTabLayout run data get storage nox_tab:work paint.character.advance 1
scoreboard players operation .Cursor NoxTabLayout += .Advance NoxTabLayout
data remove storage nox_tab:work paint.lines[0].chars[0]
execute if data storage nox_tab:work paint.lines[0].chars[0] run function nox_tab:paint/character
