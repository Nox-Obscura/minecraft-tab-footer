$data modify storage nox_tab:work paint.r set from storage nox_tab:meta hex[$(red)]
$data modify storage nox_tab:work paint.g set from storage nox_tab:meta hex[$(green)]
$data modify storage nox_tab:work paint.b set from storage nox_tab:meta hex[$(blue)]
