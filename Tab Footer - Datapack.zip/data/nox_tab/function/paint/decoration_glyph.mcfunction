$data modify storage nox_tab:work paint.decoration set from storage nox_tab:meta decorations[$(decoration_width)]
data modify storage nox_tab:work output append value {text:"",font:"nox_tab:decorations",bold:false,italic:false,shadow_color:0,extra:[{text:"\uefff"}]}
data modify storage nox_tab:work output[-1].text set from storage nox_tab:work paint.decoration
function nox_tab:paint/character_color with storage nox_tab:work paint
