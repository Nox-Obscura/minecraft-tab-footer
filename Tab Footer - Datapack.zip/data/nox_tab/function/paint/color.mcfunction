scoreboard players set .Packed NoxTabLayout 8388608
execute if data storage nox_tab:work paint.character{italic:1b} run scoreboard players add .Packed NoxTabLayout 4194304
execute store result score .Palette NoxTabLayout run data get storage nox_tab:work paint.character.palette 1
scoreboard players set .Multiplier NoxTabLayout 262144
scoreboard players operation .Palette NoxTabLayout *= .Multiplier NoxTabLayout
scoreboard players operation .Packed NoxTabLayout += .Palette NoxTabLayout
scoreboard players set .Multiplier NoxTabLayout 1024
scoreboard players operation .Temp NoxTabLayout = .Y NoxTabLayout
scoreboard players operation .Temp NoxTabLayout *= .Multiplier NoxTabLayout
scoreboard players operation .Packed NoxTabLayout += .Temp NoxTabLayout
scoreboard players operation .Packed NoxTabLayout += .X NoxTabLayout
scoreboard players set .Base NoxTabLayout 256
scoreboard players operation .Blue NoxTabLayout = .Packed NoxTabLayout
scoreboard players operation .Blue NoxTabLayout %= .Base NoxTabLayout
scoreboard players operation .Packed NoxTabLayout /= .Base NoxTabLayout
scoreboard players operation .Green NoxTabLayout = .Packed NoxTabLayout
scoreboard players operation .Green NoxTabLayout %= .Base NoxTabLayout
scoreboard players operation .Packed NoxTabLayout /= .Base NoxTabLayout
execute store result storage nox_tab:work paint.red int 1 run scoreboard players get .Packed NoxTabLayout
execute store result storage nox_tab:work paint.green int 1 run scoreboard players get .Green NoxTabLayout
execute store result storage nox_tab:work paint.blue int 1 run scoreboard players get .Blue NoxTabLayout
function nox_tab:paint/hex with storage nox_tab:work paint
