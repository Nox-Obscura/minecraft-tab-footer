$data modify storage nox_tab:work output[-1].color set value "#$(r)$(g)$(b)"
