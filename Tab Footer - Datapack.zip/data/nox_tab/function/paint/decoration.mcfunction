function nox_tab:paint/color
execute store result storage nox_tab:work paint.decoration_width int 1 run data get storage nox_tab:work paint.character.advance 1
execute store result score .DecorationWidth NoxTabLayout run data get storage nox_tab:work paint.decoration_width 1
scoreboard players remove .DecorationWidth NoxTabLayout 1
execute store result storage nox_tab:work paint.decoration_width int 1 run scoreboard players get .DecorationWidth NoxTabLayout
function nox_tab:paint/decoration_glyph with storage nox_tab:work paint
