scoreboard players add .X NoxTabLayout 1
scoreboard players add .Y NoxTabLayout 9
function nox_tab:paint/decoration
scoreboard players remove .X NoxTabLayout 1
scoreboard players remove .Y NoxTabLayout 9
