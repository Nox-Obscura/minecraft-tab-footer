$data modify storage nox_tab:work raw_root set value $(raw)
kill @e[tag=NoxTabComponentProbe]
execute summon minecraft:item_display run function nox_tab:probe/component_init
loot replace entity @e[type=item_display,tag=NoxTabComponentProbe,distance=..1,limit=1] container.0 loot nox_tab:component
execute if data entity @e[type=item_display,tag=NoxTabComponentProbe,distance=..1,limit=1] item.components."minecraft:custom_name" run scoreboard players set .ComponentOK NoxTabLayout 1
data modify storage nox_tab:work queue set value [{component:"",style:{palette:15,bold:0b,italic:0b,underlined:0b,strikethrough:0b}}]
data modify storage nox_tab:work queue[0].component set from entity @e[type=item_display,tag=NoxTabComponentProbe,distance=..1,limit=1] item.components."minecraft:custom_name"
kill @e[type=item_display,tag=NoxTabComponentProbe,distance=..1,limit=1]
function nox_tab:parse/component
