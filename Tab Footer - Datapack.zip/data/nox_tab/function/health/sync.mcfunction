scoreboard players set .MaxScoreWidth NoxTabLayout 0
execute if data storage nox_tab:config settings{score_objective:""} run return run function nox_tab:health/hidden_all
execute as @a run function nox_tab:health/player
