$execute unless entity @s[tag=NoxTabCarrier] run scoreboard players display numberformat @s NoxTabList fixed [{text:"$(value)",color:"yellow",font:"minecraft:default",bold:false,italic:false},{text:"\ueffe",font:"nox_tab:background",bold:false,italic:false,shadow_color:0}]
execute if entity @s[tag=NoxTabCarrier] run function nox_tab:health/carrier with storage nox_tab:work health
