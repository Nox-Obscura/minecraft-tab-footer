$scoreboard players display numberformat @s NoxTabList fixed $(render)
