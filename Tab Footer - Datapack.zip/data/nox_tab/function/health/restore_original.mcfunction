scoreboard players display numberformat @s health
tag @s add NoxTabHealthRestored
