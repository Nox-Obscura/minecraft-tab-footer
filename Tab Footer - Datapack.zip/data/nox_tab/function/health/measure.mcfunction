$data modify storage nox_tab:work health.text set value "$(value)"
execute store result score .ScoreWidth NoxTabLayout run data get storage nox_tab:work health.text
scoreboard players set .Six NoxTabLayout 6
scoreboard players operation .ScoreWidth NoxTabLayout *= .Six NoxTabLayout
execute if score .ScoreWidth NoxTabLayout > .MaxScoreWidth NoxTabLayout run scoreboard players operation .MaxScoreWidth NoxTabLayout = .ScoreWidth NoxTabLayout
