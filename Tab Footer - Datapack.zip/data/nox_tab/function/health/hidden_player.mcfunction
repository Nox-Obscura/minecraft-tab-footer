execute unless score @s NoxTabCache matches 0 run function nox_tab:health/hidden_format
scoreboard players set @s NoxTabList 0
scoreboard players set @s NoxTabCache 0
