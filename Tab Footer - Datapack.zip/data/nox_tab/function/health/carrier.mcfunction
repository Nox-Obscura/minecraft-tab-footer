$data modify storage nox_tab:work health.render set value [{text:"$(value)",color:"yellow",font:"minecraft:default",bold:false,italic:false}]
data modify storage nox_tab:work health.render append from storage nox_tab:work output[]
function nox_tab:health/apply with storage nox_tab:work health
