execute as @a run function nox_tab:health/hidden_player
