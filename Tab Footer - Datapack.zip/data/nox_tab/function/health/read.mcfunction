$execute if score @s $(score_objective) matches -2147483648..2147483647 run scoreboard players operation .HealthValue NoxTabLayout = @s $(score_objective)
