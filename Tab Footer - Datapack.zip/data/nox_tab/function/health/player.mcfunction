scoreboard players set .HealthValue NoxTabLayout 0
function nox_tab:health/read with storage nox_tab:config settings
execute store result storage nox_tab:work health.value int 1 run scoreboard players get .HealthValue NoxTabLayout
function nox_tab:health/measure with storage nox_tab:work health
execute unless score @s NoxTabCache = .HealthValue NoxTabLayout run function nox_tab:health/format with storage nox_tab:work health
scoreboard players operation @s NoxTabList = .HealthValue NoxTabLayout
scoreboard players operation @s NoxTabCache = .HealthValue NoxTabLayout
