execute unless entity @s[tag=NoxTabCarrier] run scoreboard players display numberformat @s NoxTabList blank
execute if entity @s[tag=NoxTabCarrier] run function nox_tab:paint/footer_only with storage nox_tab:work
