$execute as @a[nbt={UUID:$(owner)},limit=1] at @s run function nox_tab:save
data remove storage nox_tab:input request
