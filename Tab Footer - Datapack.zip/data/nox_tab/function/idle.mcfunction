schedule function nox_tab:tick 5t replace
