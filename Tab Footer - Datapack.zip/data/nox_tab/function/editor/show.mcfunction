$dialog show @s $(editor)
